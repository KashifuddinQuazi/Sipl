package com.sipl.Hello.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SiplController {

	@RequestMapping("/Hello")
	String Show() {
		return "Hello";
	}
}
